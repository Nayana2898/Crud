package com.ss;

import java.sql.SQLException;
import java.util.List;

public class CosmeticsServiceImp implements CosmeticsService{
	
	CosmeticsDAO dao=new CosmeticsDAOImp();
	@Override
	public void create(CosmeticsEntity co) throws SQLException {
		dao.createConnection();
		int a=dao.insertDetails(co);
		
		if(a>0) {
			 System.out.println("Your value has been successfully inserted...");
		 }else {
			 System.out.println("Values have not been inserted");
		 }
		dao.closeConnection();
	}

	@Override
	public void getAllCosmeticsDetails() throws SQLException {
		dao.createConnection();
		List<CosmeticsEntity> displayAllDetails = dao.displayAllDetails();
		System.out.println(displayAllDetails);
		dao.closeConnection();
	}

	@Override
	public CosmeticsEntity getCosmeticsByBrand(String brand) throws SQLException {
		dao.createConnection();
		CosmeticsEntity entity = dao.getByBrand(brand);
		System.out.println(entity);
		dao.closeConnection();
		return entity;
	}

	@Override
	public int updateCosmeticsDetails(CosmeticsEntity cos) throws SQLException {
		dao.createConnection();
		int updateDetails = dao.updateDetails(cos);
		dao.closeConnection();
		return updateDetails;
	}

	@Override
	public int deleteCosmeticsByName(String name) throws SQLException {
		dao.createConnection();
		int em=dao.deleteCosmeticsByName(name);
		dao.closeConnection();
		return em;
	}

	@Override
	public List<CosmeticsEntity> displayAllDetails() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

}
