package com.ss;

import java.util.Scanner;

public class Cosmetic {

	public static void main(String[] args) {
		CosmeticsDAO dao = new CosmeticsDAOImp();
		CosmeticsService service = new CosmeticsServiceImp();
		Scanner sc = new Scanner(System.in);
		int ch = 0;

		try {
			do {
				System.out.println("1.Insert Data\n" + "2.Display data\n" + "3.update the data\n"
						+ "4.Delete the data\n" + "5.Exit\n");
				ch = sc.nextInt();
				switch (ch) {
				case 1:
					CosmeticsEntity entity = new CosmeticsEntity();
					System.out.println("Please enter the brand :");
					entity.setBrand(sc.next());
					System.out.println("Please enter the name :");
					entity.setName(sc.next());
					System.out.println("Please enter the quantity :");
					entity.setQuantity(sc.nextInt());
					System.out.println("Please enter the color :");
					entity.setColor(sc.next());
					service.create(entity);
					break;
				case 2:
					int c=0;
					do {
						System.out.println("1.Get all details\n" + "2.Get Details of employee by brand\n"
								 + " Enter your choice:\n");
						ch = sc.nextInt();
						switch (c) {
						case 1:
							System.out.println("Details of employee are :");
							service.getAllCosmeticsDetails();
							break;
						case 2:
							System.out.println("Enter the brand of the cosmeytics you want to display");
							String brand = sc.next();
							service.getCosmeticsByBrand(brand);
							break;
						default:
							System.out.println("Please enter a correct choice....");
							break;
						}
					} while (c != 3);
				case 3:
					CosmeticsEntity cos = new CosmeticsEntity();
					System.out.println("Enter the cosmetics brand you want to update");
					cos.setBrand(sc.next());
					System.out.println("Enter the quantity you want to update");
					cos.setQuantity(sc.nextInt());
					service.updateCosmeticsDetails(cos);
					break;
				case 4:
					int choice = 0;
					do {
						System.out.println(
								"1.Delete employee by name\n" + "2.Delete employee by id\n" + " Enter your choice:\n");
						ch = sc.nextInt();
						switch (choice) {
						case 1:
							System.out.println("Enter the name of the cosmetics you want to delete :");
							String name = sc.next();
							service.deleteCosmeticsByName(name);
							break;
					default:
							System.out.println("Please enter a correct choice....");
							break;
						}
					} while (choice != 2);
					break;
				default:
					System.out.println("Please enter a correct choice!");
					break;
				}

			} while (ch != 4);

		} catch (

		Exception e) {
			System.out.println(e);
			e.printStackTrace();

		}
	}
}
