package com.ss;
import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;
	import java.util.LinkedList;
	import java.util.List;


	public class CosmeticsDAOImp implements CosmeticsDAO {

		Connection con=null;
		Statement stmt=null;
		PreparedStatement pstmt=null;
		ResultSet set=null;
		
		@Override
		public void createConnection() {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				System.out.println("Mysql driver is loaded!!");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/iprimed", "root", "Nayana@123gudimani");
				System.out.println("Got the database connection");
				stmt=con.createStatement();
			}catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Override
		public void closeConnection() throws SQLException {
			con.close();	
		}

		@Override
		public int insertDetails(CosmeticsEntity cos) throws SQLException {
			pstmt=con.prepareStatement("insert into cosmetic(brand,name,quantity,color) values(?,?,?,?);");
			pstmt.setString(1,cos.getBrand());
			pstmt.setString(2,cos.getName());
			pstmt.setInt(3, cos.getQuantity());
			pstmt.setString(4, cos.getColor());
			return pstmt.executeUpdate();
			
		}

		@Override
		public List<CosmeticsEntity> displayAllDetails() throws SQLException {
			pstmt=con.prepareStatement("select * from cosmetic");
			set=pstmt.executeQuery();
			List<CosmeticsEntity> list=new LinkedList<CosmeticsEntity>();
			while(set.next()){
			CosmeticsEntity co=new CosmeticsEntity();
			co.setBrand(set.getString("BRAND"));
			co.setName(set.getString("NAME"));
			co.setQuantity(set.getInt("QUANTITY"));
			co.setColor(set.getString("COLOR"));
			System.out.println();
			list.add(co);
			}
			return list;
			}

		@Override
		public CosmeticsEntity getByBrand(String brand) throws SQLException {
			pstmt=con.prepareStatement("select * from cometic where brand=?");
			pstmt.setString(1, brand);
			set=pstmt.executeQuery();
			set.next();
			
			CosmeticsEntity entity=new CosmeticsEntity();
			entity.setBrand(set.getString(1));
			entity.setName(set.getString(2));
			entity.setQuantity(set.getInt(3));
			entity.setColor(set.getString(4));
			return entity;
		}

		@Override
		public int updateDetails(CosmeticsEntity cos) throws SQLException {
			pstmt=con.prepareStatement("update cosmetic set quantity=? where brand=?");
			pstmt.setInt(1, cos.getQuantity());
			pstmt.setString(2, cos.getBrand());
			int count=pstmt.executeUpdate();
			return count;
		}

		@Override
		public int deleteCosmeticsByName(String name) throws SQLException{
			pstmt=con.prepareStatement("delete from cosmetic where name=?");
			pstmt.setString(1, name);
			int count=pstmt.executeUpdate();
				return count;
		}
	}
	
