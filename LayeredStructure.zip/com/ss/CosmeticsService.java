package com.ss;

import java.sql.SQLException;
import java.util.List;

public interface CosmeticsService {
    public void create(CosmeticsEntity co) throws SQLException;


	CosmeticsEntity getCosmeticsByBrand(String Brand) throws SQLException;
	List<CosmeticsEntity> displayAllDetails() throws SQLException;

	int updateCosmeticsDetails(CosmeticsEntity cos) throws SQLException;

	int deleteCosmeticsByName(String name) throws SQLException;

	void getAllCosmeticsDetails() throws SQLException;
}
