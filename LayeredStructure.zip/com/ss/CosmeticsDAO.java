package com.ss;

import java.sql.SQLException;
import java.util.List;

public interface CosmeticsDAO {
	
	void createConnection();

	void closeConnection() throws SQLException;

	int insertDetails(CosmeticsEntity cos) throws SQLException;

	List<CosmeticsEntity> displayAllDetails() throws SQLException;

	CosmeticsEntity getByBrand(String brand) throws SQLException;

	int updateDetails(CosmeticsEntity cos) throws SQLException;

	int deleteCosmeticsByName(String name) throws SQLException;
}
